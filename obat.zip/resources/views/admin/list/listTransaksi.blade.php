@extends('layouts.adminLayout')

@section('content')
<div class="main-content">
    <header class="header">
        <div class="header-left">
            <button class="menu-toggle">
                <i class="fas fa-bars"></i>
            </button>
            <h1 id="page-title">Data Transaksi</h1>
        </div>
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input type="text" placeholder="Cari transaksi..." id="searchInput">
        </div>
    </header>

    <section class="content-section active">
        @if (session('success'))
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> {{ session('success') }}
        </div>
        @endif

        <div class="section-header">
            <h2>Daftar Transaksi</h2>
            <div>
                <span class="filter-btn">Total: {{ $pemesanan->count() }}</span>
            </div>
        </div>

        @if($pemesanan->isEmpty())
        <div class="table-container">
            <div style="padding: 3rem; text-align: center; color: #999;">
                <i class="fas fa-inbox" style="font-size: 3rem; margin-bottom: 1rem; display: block;"></i>
                <p>Belum ada transaksi</p>
            </div>
        </div>
        @else
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Kode Pesanan</th>
                        <th>Nama Pembeli</th>
                        <th>Klinik</th>
                        <th>Nomor HP</th>
                        <th>Total Harga</th>
                        <th>Tipe</th>
                        <th>Status</th>
                        <th>Tanggal Pesanan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($pemesanan as $item)
                    <tr>
                        <td>
                            <strong>{{ $item->kodePemesanan }}</strong>
                        </td>
                        <td>{{ $item->user->username ?? '-' }}</td>
                        <td>{{ $item->user->klinik->namaKlinik ?? '-' }}</td>
                        <td>{{ $item->user->phoneNumber ?? '-' }}</td>
                        <td>Rp {{ number_format($item->totalHarga, 0, ',', '.') }}</td>
                        <td>
                            @if(in_array(strtolower($item->tipePembayaran ?? $item->typePembayaran), ['credit', 'kredit']))
                                <span class="status pending" style="font-weight: 600; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem; display: inline-flex; align-items: center; gap: 4px;"><i class="fas fa-calendar-alt"></i> Credit</span>
                            @else
                                <span class="status completed" style="font-weight: 600; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem; display: inline-flex; align-items: center; gap: 4px; background: #e2e8f0; color: #475569;"><i class="fas fa-wallet"></i> Cash</span>
                            @endif
                        </td>
                        <td>
                            <span class="status {{ str_replace(' ', '-', strtolower($item->status)) }}">
                                {{ ucfirst($item->status) }}
                            </span>
                        </td>
                        <td>{{ $item->created_at->format('d/m/Y H:i') }}</td>
                        <td>
                            <div class="action-links" style="display: flex; gap: 0.5rem; align-items: center; justify-content: center;">
                                @if($item->status === 'Menunggu Persetujuan')
                                    <form action="{{ route('approveTransaksi', $item->id) }}" method="POST" style="margin: 0; display: inline;">
                                        @csrf
                                        <button type="submit" class="action-link" style="color: #10b981; background: none; border: none; cursor: pointer; font-weight: 600;" onclick="return confirm('Apakah Anda yakin ingin menyetujui transaksi ini?');">Approve</button>
                                    </form>
                                    <span style="color: #cbd5e1;">|</span>
                                    <form action="{{ route('denyTransaksi', $item->id) }}" method="POST" style="margin: 0; display: inline;">
                                        @csrf
                                        <button type="submit" class="action-link delete" style="color: #ef4444; background: none; border: none; cursor: pointer; font-weight: 600;" onclick="return confirm('Apakah Anda yakin ingin menolak transaksi ini?');">Deny</button>
                                    </form>
                                @else
                                    <span style="color: #94a3b8; font-size: 0.85rem;">-</span>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        @endif
    </section>
</div>

<!-- Modal Detail -->
<div id="detailModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Detail Transaksi</h3>
            <button type="button" class="close-modal" onclick="closeModal()">×</button>
        </div>
        <div class="admin-form" id="detailContent">
            <!-- Isi detail akan dimuat melalui AJAX -->
        </div>
    </div>
</div>

<style>
    .alert {
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 2rem;
    }

    .alert-success {
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }

    .status.pending {
        background: #fff3cd;
        color: #856404;
    }

    .status.completed {
        background: #d4edda;
        color: #155724;
    }

    .status.cancelled {
        background: #f8d7da;
        color: #721c24;
    }

    .status.menunggu-persetujuan {
        background: #e0f2fe;
        color: #0369a1;
    }

    .status.ditolak {
        background: #fee2e2;
        color: #b91c1c;
    }

    .status.invoice {
        background: #eff6ff;
        color: #1e40af;
        border: 1px solid rgba(30, 64, 175, 0.2);
    }
</style>

<script>
    function viewDetail(id) {
        fetch(`/pemesanan/${id}/detail`)
            .then(response => response.json())
            .then(data => {
                let html = `
                    <div style="margin-bottom: 1.5rem;">
                        <h4>Informasi Pesanan</h4>
                        <p><strong>Kode Pesanan:</strong> ${data.kodePemesanan}</p>
                        <p><strong>Nama Pembeli:</strong> ${data.user.username}</p>
                        <p><strong>Nomor HP:</strong> ${data.user.phoneNumber}</p>
                        <p><strong>Alamat:</strong> ${data.user.alamat || '-'}</p>
                        <p><strong>Total Harga:</strong> Rp ${new Intl.NumberFormat('id-ID').format(data.totalHarga)}</p>
                        <p><strong>Status:</strong> ${data.status}</p>
                        <p><strong>Tanggal Pesanan:</strong> ${new Date(data.created_at).toLocaleDateString('id-ID')}</p>
                    </div>
                    <div>
                        <h4>Detail Produk</h4>
                        <table class="data-table" style="font-size: 0.9rem;">
                            <thead>
                                <tr>
                                    <th>Nama Produk</th>
                                    <th>Jumlah</th>
                                    <th>Harga</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${data.details.map(detail => `
                                    <tr>
                                        <td>${detail.produk.namaProduk}</td>
                                        <td>${detail.jumlahBeli}</td>
                                        <td>Rp ${new Intl.NumberFormat('id-ID').format(detail.harga)}</td>
                                        <td>Rp ${new Intl.NumberFormat('id-ID').format(detail.harga * detail.jumlahBeli)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
                document.getElementById('detailContent').innerHTML = html;
                document.getElementById('detailModal').style.display = 'flex';
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Gagal memuat detail transaksi');
            });
    }

    function closeModal() {
        document.getElementById('detailModal').style.display = 'none';
    }

    window.onclick = function(event) {
        const modal = document.getElementById('detailModal');
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
</script>

@endsection