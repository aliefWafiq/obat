<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  Closure(Request): (Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        if (auth()->check() && (auth()->user()->role == 'Admin' || auth()->user()->role == 'SuperAdmin')) {
            return $next($request);
        }

        return redirect('/home')->with('error', 'Anda tidak memiliki akses ke halaman ini.');
    }
}
