Halo <?php echo e($userName); ?>,
Kode OTP Anda adalah *<?php echo e($code); ?>*. Kode ini berlaku selama 5 menit.
Terima kasih.<?php /**PATH E:\1.CODING\1.Shigoto\1.Obat\obat\resources\views/auth/otp_message.blade.php ENDPATH**/ ?>