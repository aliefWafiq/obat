<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(setting('namaAplikasi')); ?></title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/obatkitalogo.png')); ?>">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('style/admin.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header" style="flex-direction: column; align-items: flex-start; gap: 4px; padding: 1.5rem 1.75rem;">
            <div style="height: 45px; width: 100%; display: flex; align-items: center; justify-content: flex-start; overflow: hidden;">
                <img src="<?php echo e(asset('img/obatkitaputih.png')); ?>" alt="ObatKita" style="height: 280px; object-fit: contain; margin-left: -50px; margin-right: -50px;">
            </div>
            <div style="font-size: 0.85rem; color: #818cf8; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; margin-top: 5px; margin-left: 2px;">
                <?php echo e(auth()->user()->role === 'SuperAdmin' ? 'Super Admin' : 'Admin'); ?>

            </div>
        </div>
        <nav class="sidebar-nav">
            <!-- CORE MENU -->
            <div class="nav-section-title">Core / Utama</div>
            <a href="<?php echo e(route('dashboard')); ?>" class="nav-item" data-section="dashboard">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>

            <!-- SALES & TRANSACTIONS -->
            <div class="nav-section-title">Transaksi & Penjualan</div>
            <a href="<?php echo e(route('listTransaksi')); ?>" class="nav-item" data-section="transaksi">
                <i class="fas fa-exchange-alt"></i> Transaksi
            </a>
            <a href="<?php echo e(route('listPenjualan')); ?>" class="nav-item" data-section="penjualan">
                <i class="fas fa-chart-line"></i> Laporan Penjualan
            </a>
            <a href="<?php echo e(route('listInvoice')); ?>" class="nav-item" data-section="invoices">
                <i class="fas fa-file-invoice-dollar"></i> Invoice & Tagihan
            </a>

            <!-- INVENTORY & MEDICINES -->
            <div class="nav-section-title">Inventaris & Produk</div>
            <a href="<?php echo e(route('listProduk')); ?>" class="nav-item" data-section="obat">
                <i class="fas fa-capsules"></i> Data Obat
            </a>
            <?php if(auth()->user()->role === 'SuperAdmin'): ?>
            <a href="<?php echo e(route('listCategory')); ?>" class="nav-item" data-section="kategori">
                <i class="fas fa-tags"></i> Kategori Obat
            </a>
            <?php endif; ?>
            <a href="#" class="nav-item" data-section="supplier" onclick="alert('coming soon ya geng :>')">
                <i class="fas fa-truck-loading"></i> Data Supplier
            </a>

            <!-- USER & CLINIC MANAGEMENT -->
            <div class="nav-section-title">Manajemen Klinik & User</div>
            <a href="<?php echo e(route('listAkun')); ?>" class="nav-item" data-section="akun">
                <i class="fas fa-users-cog"></i> Data Akun
            </a>
            <a href="<?php echo e(route('listUser')); ?>" class="nav-item" data-section="user" style="padding-left: 2rem; font-size: 0.85rem;">
                <i class="fas fa-user-md"></i> Daftar Dokter
            </a>
            <?php if(auth()->user()->role === 'SuperAdmin' || auth()->user()->role === 'Admin'): ?>
            <a href="<?php echo e(route('listKlinik')); ?>" class="nav-item" data-section="klinik" style="padding-left: 2rem; font-size: 0.85rem;">
                <i class="fas fa-clinic-medical"></i> Daftar Klinik
            </a>
            <?php endif; ?>

            <!-- PROMOTIONS & MARKETING -->
            <?php if(auth()->user()->role === 'SuperAdmin'): ?>
            <div class="nav-section-title">Promosi & Program</div>
            <a href="<?php echo e(route('listProgram')); ?>" class="nav-item" data-section="BuatProgram">
                <i class="fas fa-gift"></i> Buat Program
            </a>
            <a href="<?php echo e(route('listDiskon')); ?>" class="nav-item" data-section="BuatDiskon">
                <i class="fas fa-percentage"></i> List Diskon
            </a>
            <?php endif; ?>

            <!-- SYSTEM & SUPPORT -->
            <?php if(auth()->user()->role === 'SuperAdmin'): ?>
            <div class="nav-section-title">Sistem & Bantuan</div>
            <a href="<?php echo e(route('virtualWebsite')); ?>" class="nav-item" data-section="virtual-website">
                <i class="fas fa-globe"></i> Virtual Website
            </a>
            <a href="<?php echo e(route('viewSettings')); ?>" class="nav-item" data-section="settings">
                <i class="fas fa-sliders-h"></i> Pengaturan
            </a>
            <a href="<?php echo e(route('viewActivityLogs')); ?>" class="nav-item" data-section="activity-logs">
                <i class="fas fa-history"></i> Log Aktivitas
            </a>
            <?php endif; ?>
        </nav>
        <div class="sidebar-footer">
            <div class="user-info">
                <img src="<?php echo e(asset('img/397057724_11539820.png')); ?>" alt="Admin" class="user-avatar">
                <div>
                    <p><?php echo e(Auth::user()->username); ?></p>
                    <small><?php echo e(Auth::user()->phoneNumber); ?></small>
                </div>
            </div>
            <a href="<?php echo e(route('logOut')); ?>">
                <button class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </a>
        </div>
    </div>

    <!-- Main Content -->

    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
</body>

</html><?php /**PATH E:\1.CODING\1.Shigoto\1.Obat\obat\resources\views/layouts/adminLayout.blade.php ENDPATH**/ ?>