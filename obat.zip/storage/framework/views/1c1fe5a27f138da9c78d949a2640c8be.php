<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e(setting('namaAplikasi')); ?></title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/obatkitalogo.png')); ?>">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <nav class="navbar" id="navbar">
        <a href="<?php echo e(Auth::check() ? route('home') : route('landingPage')); ?>" class="logo">
            <img src="<?php echo e(asset('img/obatkitalogo.png')); ?>" alt="">
        </a>

        <?php echo $__env->yieldContent('nav'); ?>

        <ul class="nav-links">
            <li><a href="https://wa.me/6287877770155">Kontak</a></li>
            <?php if(Auth::check()): ?>
            <li><a href="<?php echo e(route('keranjang')); ?>">Keranjang</a></li>
            <li><a href="<?php echo e(route('pemesanan')); ?>">Pemesanan</a></li>
            <li><a href="<?php echo e(route('logOut')); ?>">Keluar</a></li>
            <?php else: ?>
            <li><a href="#services">Layanan</a></li>
            <li><a href="<?php echo e(route('login')); ?>" class="btn-login">Masuk</a></li>
            <?php endif; ?>
        </ul>

        <button class="mobile-toggle" id="mobileToggle">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </nav>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    
</body>

</html><?php /**PATH E:\1.CODING\1.Shigoto\1.Obat\obat\resources\views/layouts/mainLayout.blade.php ENDPATH**/ ?>