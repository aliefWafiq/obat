<?php $__env->startSection('content'); ?>
<div class="main-content">
    <header class="header">
        <div class="header-left">
            <button class="menu-toggle">
                <i class="fas fa-bars"></i>
            </button>
            <h1 id="page-title">Edit Akun Pengguna</h1>
        </div>
    </header>

    <section class="content-section active" style="display: flex; justify-content: center; padding: 2rem 1rem;">
        <div style="width: min(700px, 100%); background: #ffffff; border-radius: 24px; padding: 2rem; box-shadow: 0 18px 40px rgba(0,0,0,0.08);">
            <?php if(session('success')): ?>
            <div class="alert alert-success" style="margin-bottom: 1.5rem;">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger" style="margin-bottom: 1.5rem;">
                <ul style="margin: 0; padding-left: 1.2rem;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <div style="display: flex; justify-content: space-between; align-items: center; gap: 1rem; flex-wrap: wrap; margin-bottom: 1.5rem;">
                <div>
                    <h2 style="margin: 0; font-size: 1.75rem;">Detail Akun</h2>
                    <p style="margin: 0.5rem 0 0; color: #6b7280;">Perbarui informasi pengguna dengan cepat dan aman.</p>
                </div>
                <a href="<?php echo e(route('listUser')); ?>" class="btn btn-secondary" style="padding: 0.9rem 1.4rem; font-size: 0.95rem; display: inline-flex; align-items: center; gap: 0.6rem;">
                    <i class="fas fa-arrow-left"></i> Kembali ke daftar
                </a>
            </div>

            <form action="<?php echo e(route('updateUser', $users->id)); ?>" method="POST" class="admin-form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i> Username <span style="color: #ff4757;">*</span>
                    </label>
                    <input type="text" id="username" name="username" required placeholder="Masukkan username" value="<?php echo e(old('username', $users->username)); ?>">
                </div>

                <div class="form-group">
                    <label for="phoneNumber">
                        <i class="fas fa-phone"></i> Nomor HP <span style="color: #ff4757;">*</span>
                    </label>
                    <input type="text" id="phoneNumber" name="phoneNumber" required placeholder="08xxxxxxxxxx" value="<?php echo e(old('phoneNumber', $users->phoneNumber)); ?>">
                </div>

                <div class="form-group">
                    <label for="alamat">
                        <i class="fas fa-map-marker-alt"></i> Alamat Lengkap <span style="color: #ff4757;">*</span>
                    </label>
                    <textarea id="alamat" name="alamat" placeholder="Masukkan alamat lengkap" style="min-height: 130px;"><?php echo e(old('alamat', $users->alamat)); ?></textarea>
                </div>

                <?php if(auth()->user()->role === 'SuperAdmin' && $users->role === 'User'): ?>
                <div class="form-group" id="clinic-group">
                    <label for="idKlinik">
                        <i class="fas fa-clinic-medical"></i> Klinik / Admin Pengampu <span style="color: #ff4757;">*</span>
                    </label>
                    <select id="idKlinik" name="idKlinik">
                        <option value="">Pilih Klinik...</option>
                        <?php $__currentLoopData = $clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($clinic->id); ?>" <?php echo e(old('idKlinik', $users->idKlinik) == $clinic->id ? 'selected' : ''); ?>>
                                <?php echo e($clinic->namaKlinik); ?> (<?php echo e($clinic->kodeKlinik); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php endif; ?>

                <div class="form-actions" style="margin-top: 1.8rem; display: flex; gap: 1rem; flex-wrap: wrap; justify-content: flex-end;">
                    <a href="<?php echo e(route('listUser')); ?>" class="btn btn-secondary" style="padding: 0.95rem 1.4rem; display: inline-flex; align-items: center; gap: 0.5rem;">
                        <i class="fas fa-times"></i> Batal
                    </a>
                    <button type="submit" class="btn btn-primary" style="padding: 0.95rem 1.6rem; display: inline-flex; align-items: center; gap: 0.6rem;">
                        <i class="fas fa-check"></i> Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\1.CODING\1.Shigoto\1.Obat\obat\resources\views/admin/edit/editUser.blade.php ENDPATH**/ ?>