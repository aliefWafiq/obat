<?php $__env->startSection('content'); ?>
<div class="main-content">
    <header class="header">
        <div class="header-left">
            <button class="menu-toggle">
                <i class="fas fa-bars"></i>
            </button>
            <h1 id="page-title">Daftar Akun</h1>
        </div>
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input type="text" placeholder="Cari pengguna..." id="searchInput">
        </div>
    </header>

    <section class="content-section active">
        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <div class="section-header">
            <h2>Daftar Akun</h2>
            <div>
                <span class="filter-btn">Total: <?php echo e($users->count()); ?> Akun</span>
            </div>
        </div>

            <div class="account-management-grid<?php echo e(auth()->user()->role !== 'SuperAdmin' ? ' full-width' : ''); ?>">
                <div class="account-main-panel">
                    <div class="account-summary-grid">
                        <div class="account-summary-card primary">
                            <div>
                                <h3><?php echo e($users->count()); ?></h3>
                                <p>Total Akun Terdaftar</p>
                            </div>
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="account-summary-card secondary">
                            <div>
                                <h3><?php echo e($users->where('role', 'Admin')->count()); ?></h3>
                                <p>Akun Admin (Klinik)</p>
                            </div>
                            <i class="fas fa-user-shield"></i>
                        </div>
                        <div class="account-summary-card accent">
                            <div>
                                <h3><?php echo e($users->where('role', 'User')->count()); ?></h3>
                                <p>Akun Pengguna (Dokter)</p>
                            </div>
                            <i class="fas fa-user-friends"></i>
                        </div>
                    </div>

                    
                    <div class="tabs-container" style="margin-top: 1.5rem; margin-bottom: 0.5rem; display: flex; gap: 8px; border-bottom: 2px solid #e2e8f0;">
                        <button class="tab-btn active" onclick="switchTab(event, 'akun-tab')" style="background: none; border: none; padding: 10px 16px; font-weight: 600; font-size: 0.9rem; color: #6366f1; border-bottom: 2px solid #6366f1; cursor: pointer; transition: all 0.2s; margin-bottom: -2px;">
                            <i class="fas fa-users-cog" style="margin-right: 6px;"></i> Daftar Akun
                        </button>
                        <button class="tab-btn" onclick="switchTab(event, 'klinik-tab')" style="background: none; border: none; padding: 10px 16px; font-weight: 600; font-size: 0.9rem; color: #64748b; cursor: pointer; transition: all 0.2s; margin-bottom: -2px;">
                            <i class="fas fa-clinic-medical" style="margin-right: 6px;"></i> Data Klinik
                        </button>
                    </div>

                    <div id="akun-tab" class="tab-pane">
                        <?php if($users->isEmpty()): ?>
                        <div class="data-card" style="margin-top: 1.5rem; padding: 3rem; text-align: center; color: #64748b;">
                            <i class="fas fa-inbox" style="font-size: 2rem; margin-bottom: 1rem; color: #cbd5e1; display: block;"></i>
                            Belum ada akun pengguna.
                        </div>
                        <?php else: ?>
                        <div class="data-card" style="margin-top: 1rem;">
                            <table class="formal-table" id="accountsTable">
                                <thead>
                                    <tr>
                                        <th style="width: 40px;"></th>
                                        <th>Profil Akun / Klinik</th>
                                        <th>Kontak & Lokasi</th>
                                        <th>Status / Peran</th>
                                        <?php if(auth()->user()->role === 'SuperAdmin'): ?>
                                        <th>Aksi</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php if(auth()->user()->role === 'SuperAdmin'): ?>
                                    <?php $__currentLoopData = $users->where('role', 'SuperAdmin'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="main-row searchable-row" style="background: rgba(99, 102, 241, 0.02);">
                                        <td style="text-align: center;">
                                            <i class="fas fa-lock" style="color: #cbd5e1; font-size: 0.8rem;"></i>
                                        </td>
                                        <td>
                                            <div class="user-info-cell">
                                                <div class="user-icon" style="background: rgba(99, 102, 241, 0.1); color: #6366f1;">
                                                    <i class="fas fa-crown"></i>
                                                </div>
                                                <div class="user-details">
                                                    <h4 class="searchable-name"><?php echo e($item->username); ?></h4>
                                                    <span>ID: #<?php echo e(str_pad($item->id, 4, '0', STR_PAD_LEFT)); ?></span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div style="color: #334155;"><i class="fas fa-phone-alt" style="color: #94a3b8; width: 20px;"></i> <?php echo e($item->phoneNumber); ?></div>
                                        </td>
                                        <td>
                                            <span class="role-badge role-superadmin">Super Admin</span>
                                        </td>
                                        <td>
                                            <div class="action-links">
                                                <a href="<?php echo e(route('viewEditUser', $item->id)); ?>" class="action-link">Edit</a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    
                                    <?php $__currentLoopData = $users->where('role', 'Admin'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(auth()->user()->role === 'SuperAdmin' || auth()->user()->idKlinik === $item->idKlinik): ?>
                                    <?php
                                    $clinicDoctors = $users->where('role', 'User')->where('idKlinik', $item->idKlinik);
                                    ?>
                                    <tr class="main-row searchable-row" data-admin-id="<?php echo e($item->id); ?>" onclick="toggleSubRow('users-of-<?php echo e($item->id); ?>', this)">
                                        <td style="text-align: center;">
                                            <i class="fas fa-chevron-right expand-indicator"></i>
                                        </td>
                                        <td>
                                            <div class="user-info-cell">
                                                <div class="user-icon" style="background: rgba(59, 130, 246, 0.1); color: #3b82f6; border-radius: 8px;">
                                                    <i class="fas fa-hospital"></i>
                                                </div>
                                                <div class="user-details">
                                                    <h4 class="searchable-name"><?php echo e($item->username); ?></h4>
                                                    <span>Kode: <?php echo e($item->klinik ? $item->klinik->kodeKlinik : '-'); ?></span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div style="color: #334155; margin-bottom: 2px;"><i class="fas fa-phone-alt" style="color: #94a3b8; width: 20px;"></i> <?php echo e($item->phoneNumber); ?></div>
                                            <div style="font-size: 0.8rem; color: #64748b; padding-left: 20px;"><?php echo e($item->alamat ?: '-'); ?></div>
                                        </td>
                                        <td>
                                            <span class="role-badge role-admin" style="margin-right: 5px;">Admin</span>
                                            <span class="clinic-badge"><?php echo e($clinicDoctors->count()); ?> Dokter</span>
                                        </td>
                                        <?php if(auth()->user()->role === 'SuperAdmin'): ?>
                                        <td onclick="event.stopPropagation()">
                                            <div class="action-links">
                                                <a href="<?php echo e(route('viewEditUser', $item->id)); ?>" class="action-link">Edit</a>
                                                <span style="color: #cbd5e1;">|</span>
                                                <form action="<?php echo e(route('deleteUser', $item->id)); ?>" method="POST" onsubmit="return confirm('Menghapus Admin ini juga akan menghapus klinik terkait. Lanjutkan?');" style="margin: 0; display: inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="action-link delete">Hapus</button>
                                                </form>
                                            </div>
                                        </td>
                                        <?php endif; ?>
                                    </tr>

                                    
                                    <tr class="sub-row" id="users-of-<?php echo e($item->id); ?>">
                                        <td colspan="<?php echo e(auth()->user()->role === 'SuperAdmin' ? 5 : 4); ?>" style="padding: 0;">
                                            <div class="sub-table-container">
                                                <h5 style="margin: 0 0 0.75rem 0; color: #1e293b; font-size: 0.9rem;">
                                                    <i class="fas fa-user-md" style="color: #6366f1; margin-right: 6px;"></i>
                                                    Daftar Dokter Bertugas di <?php echo e($item->username); ?>

                                                </h5>

                                                <?php if($clinicDoctors->isEmpty()): ?>
                                                <div class="empty-sub-state" style="padding: 1.5rem; text-align: center; color: #64748b; border: 1px dashed #e2e8f0; border-radius: 8px;">
                                                    Tidak ada dokter ditugaskan di klinik ini.
                                                </div>
                                                <?php else: ?>
                                                <table class="sub-table">
                                                    <thead>
                                                        <tr>
                                                            <th>Nama Dokter</th>
                                                            <th>Kontak</th>
                                                            <th>Alamat</th>
                                                            <?php if(auth()->user()->role === 'SuperAdmin'): ?>
                                                            <th>Pindah Penugasan</th>
                                                            <th>Aksi</th>
                                                            <?php endif; ?>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $clinicDoctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>
                                                                <div style="display: flex; align-items: center; gap: 0.5rem; font-weight: 600; color: #0f172a;">
                                                                    <i class="fas fa-user-md" style="color: #94a3b8;"></i>
                                                                    <?php echo e($doc->username); ?>

                                                                </div>
                                                            </td>
                                                            <td><?php echo e($doc->phoneNumber); ?></td>
                                                            <td><?php echo e($doc->alamat ?: '-'); ?></td>
                                                            <?php if(auth()->user()->role === 'SuperAdmin'): ?>
                                                            <td>
                                                                <form action="<?php echo e(route('reassignUserClinic', $doc->id)); ?>" method="POST" style="margin: 0;">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('PUT'); ?>
                                                                    <select name="idKlinik" class="formal-select" onchange="this.form.submit()">
                                                                        <option value="">-- Pindah Klinik --</option>
                                                                        <?php $__currentLoopData = $clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($c->id); ?>" <?php echo e($doc->idKlinik == $c->id ? 'selected' : ''); ?>>
                                                                            <?php echo e($c->namaKlinik); ?>

                                                                        </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </form>
                                                            </td>
                                                            <td>
                                                                <div class="action-links">
                                                                    <a href="<?php echo e(route('viewEditUser', $doc->id)); ?>" class="action-link">Edit</a>
                                                                    <span style="color: #cbd5e1;">|</span>
                                                                    <form action="<?php echo e(route('deleteUser', $doc->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus dokter ini?');" style="margin: 0; display: inline;">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <button type="submit" class="action-link delete">Hapus</button>
                                                                    </form>
                                                                </div>
                                                            </td>
                                                            <?php endif; ?>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    
                                    <?php
                                    $unassignedDoctors = $users->where('role', 'User')->whereNull('idKlinik');
                                    ?>
                                    <?php if($unassignedDoctors->isNotEmpty()): ?>
                                    <tr class="main-row searchable-row" data-admin-id="unassigned" onclick="toggleSubRow('users-of-unassigned', this)" style="background: rgba(239, 68, 68, 0.01);">
                                        <td style="text-align: center;">
                                            <i class="fas fa-chevron-right expand-indicator" style="color: #ef4444;"></i>
                                        </td>
                                        <td>
                                            <div class="user-info-cell">
                                                <div class="user-icon" style="background: #fff1f2; color: #ef4444; border-radius: 8px;">
                                                    <i class="fas fa-exclamation-triangle"></i>
                                                </div>
                                                <div class="user-details">
                                                    <h4 class="searchable-name" style="color: #b91c1c;">Dokter Tanpa Klinik (Pool)</h4>
                                                    <span style="color: #ef4444;">Status: Belum Terdistribusi</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>-</td>
                                        <td>
                                            <span class="role-badge role-unassigned" style="margin-right: 5px;">Pool</span>
                                            <span class="clinic-badge unassigned-badge"><?php echo e($unassignedDoctors->count()); ?> Dokter</span>
                                        </td>
                                        <?php if(auth()->user()->role === 'SuperAdmin'): ?>
                                        <td>-</td>
                                        <?php endif; ?>
                                    </tr>

                                    
                                    <tr class="sub-row" id="users-of-unassigned">
                                        <td colspan="<?php echo e(auth()->user()->role === 'SuperAdmin' ? 5 : 4); ?>" style="padding: 0;">
                                            <div class="sub-table-container">
                                                <h5 style="margin: 0 0 0.75rem 0; color: #b91c1c; font-size: 0.9rem;">
                                                    <i class="fas fa-exclamation-circle" style="color: #ef4444; margin-right: 6px;"></i>
                                                    Daftar Dokter Belum Ditugaskan
                                        </h5>
                                                <table class="sub-table">
                                                    <thead>
                                                        <tr>
                                                            <th>Nama Dokter</th>
                                                            <th>Kontak</th>
                                                            <th>Alamat</th>
                                                            <?php if(auth()->user()->role === 'SuperAdmin'): ?>
                                                            <th>Tentukan Penugasan</th>
                                                            <th>Aksi</th>
                                                            <?php endif; ?>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $unassignedDoctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>
                                                                <div style="display: flex; align-items: center; gap: 0.5rem; font-weight: 600; color: #0f172a;">
                                                                    <i class="fas fa-user-md" style="color: #f87171;"></i>
                                                                    <?php echo e($doc->username); ?>

                                                                </div>
                                                            </td>
                                                            <td><?php echo e($doc->phoneNumber); ?></td>
                                                            <td><?php echo e($doc->alamat ?: '-'); ?></td>
                                                            <?php if(auth()->user()->role === 'SuperAdmin'): ?>
                                                            <td>
                                                                <form action="<?php echo e(route('reassignUserClinic', $doc->id)); ?>" method="POST" style="margin: 0;">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('PUT'); ?>
                                                                    <select name="idKlinik" class="formal-select" onchange="this.form.submit()">
                                                                        <option value="">Pilih Klinik...</option>
                                                                        <?php $__currentLoopData = $clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($c->id); ?>">
                                                                            <?php echo e($c->namaKlinik); ?>

                                                                        </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </form>
                                                            </td>
                                                            <td>
                                                                <div class="action-links">
                                                                    <a href="<?php echo e(route('viewEditUser', $doc->id)); ?>" class="action-link">Edit</a>
                                                                    <span style="color: #cbd5e1;">|</span>
                                                                    <form action="<?php echo e(route('deleteUser', $doc->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus dokter ini?');" style="margin: 0; display: inline;">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <button type="submit" class="action-link delete">Hapus</button>
                                                                    </form>
                                                                </div>
                                                            </td>
                                                            <?php endif; ?>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div id="klinik-tab" class="tab-pane" style="display: none;">
                        <div class="data-card" style="margin-top: 1rem;">
                            <table class="formal-table" id="clinicsTable">
                                <thead>
                                    <tr>
                                        <th style="width: 40px;"></th>
                                        <th>Informasi Klinik</th>
                                        <th>Kontak & Lokasi</th>
                                        <th>Status</th>
                                        <?php if(auth()->user()->role === 'SuperAdmin'): ?>
                                        <th>Aksi</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $clinicsOnly = $users->where('role', 'Admin');
                                    ?>

                                    <?php if($clinicsOnly->isEmpty()): ?>
                                    <tr>
                                        <td colspan="<?php echo e(auth()->user()->role === 'SuperAdmin' ? 5 : 4); ?>" style="text-align: center; padding: 3rem; color: #64748b;">
                                            <i class="fas fa-inbox" style="font-size: 2rem; margin-bottom: 1rem; color: #cbd5e1; display: block;"></i>
                                            Belum ada data klinik terdaftar.
                                        </td>
                                    </tr>
                                    <?php else: ?>
                                    <?php $__currentLoopData = $clinicsOnly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(auth()->user()->role === 'SuperAdmin' || auth()->user()->idKlinik === $item->idKlinik): ?>
                                    <?php
                                    $doctorsInClinic = $users->where('role', 'User')->where('idKlinik', $item->idKlinik);
                                    ?>
                                    <tr class="main-row searchable-row" onclick="toggleSubRow('clinic-detail-<?php echo e($item->id); ?>', this)">
                                        <td style="text-align: center;">
                                            <i class="fas fa-chevron-right expand-indicator"></i>
                                        </td>
                                        <td>
                                            <div class="user-info-cell">
                                                <div class="user-icon" style="background: rgba(59, 130, 246, 0.1); color: #3b82f6; border-radius: 8px;">
                                                    <i class="fas fa-hospital"></i>
                                                </div>
                                                <div class="user-details">
                                                    <h4 class="searchable-name"><?php echo e($item->username); ?></h4>
                                                    <span>Kode: <?php echo e($item->klinik ? $item->klinik->kodeKlinik : '-'); ?></span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div style="color: #334155; margin-bottom: 2px;"><i class="fas fa-phone-alt" style="color: #94a3b8; width: 20px;"></i> <?php echo e($item->phoneNumber); ?></div>
                                            <div style="font-size: 0.8rem; color: #64748b; padding-left: 20px;"><?php echo e($item->alamat ?: '-'); ?></div>
                                        </td>
                                        <td>
                                            <span class="clinic-badge"><?php echo e($doctorsInClinic->count()); ?> Dokter Bertugas</span>
                                        </td>
                                        <?php if(auth()->user()->role === 'SuperAdmin'): ?>
                                        <td onclick="event.stopPropagation()">
                                            <div class="action-links">
                                                <a href="<?php echo e(route('viewEditUser', $item->id)); ?>" class="action-link">Edit</a>
                                                <span style="color: #cbd5e1;">|</span>
                                                <form action="<?php echo e(route('deleteUser', $item->id)); ?>" method="POST" onsubmit="return confirm('Menghapus Admin ini juga akan menghapus klinik terkait. Lanjutkan?');" style="margin: 0; display: inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="action-link delete">Hapus</button>
                                                </form>
                                            </div>
                                        </td>
                                        <?php endif; ?>
                                    </tr>
                                    <tr class="sub-row" id="clinic-detail-<?php echo e($item->id); ?>">
                                        <td colspan="<?php echo e(auth()->user()->role === 'SuperAdmin' ? 5 : 4); ?>" style="padding: 0;">
                                            <div class="sub-table-container">
                                                <div style="margin-bottom: 1.5rem; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                                    <h5 style="margin: 0 0 1rem 0; color: #1e293b; font-size: 0.95rem; border-bottom: 1px solid #f1f5f9; padding-bottom: 0.5rem; font-weight: 700;">Detail Informasi Klinik</h5>
                                                    <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                                                        <tr>
                                                            <td style="width: 180px; color: #64748b; padding: 0.6rem 0; border-bottom: 1px solid #f8fafc;">Nama Klinik (Akun Admin)</td>
                                                            <td style="color: #0f172a; padding: 0.6rem 0; font-weight: 600; border-bottom: 1px solid #f8fafc;"><?php echo e($item->username); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="color: #64748b; padding: 0.6rem 0; border-bottom: 1px solid #f8fafc;">Kode Klinik</td>
                                                            <td style="color: #0f172a; padding: 0.6rem 0; font-weight: 600; border-bottom: 1px solid #f8fafc;"><?php echo e($item->klinik ? $item->klinik->kodeKlinik : '-'); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="color: #64748b; padding: 0.6rem 0; border-bottom: 1px solid #f8fafc;">Kontak (No. HP)</td>
                                                            <td style="color: #0f172a; padding: 0.6rem 0; font-weight: 600; border-bottom: 1px solid #f8fafc;"><?php echo e($item->phoneNumber); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="color: #64748b; padding: 0.6rem 0;">Alamat Lengkap</td>
                                                            <td style="color: #0f172a; padding: 0.6rem 0; font-weight: 600;"><?php echo e($item->alamat ?: '-'); ?></td>
                                                        </tr>
                                                    </table>
                                                </div>

                                                <h5 style="margin: 0 0 0.75rem 0; color: #1e293b; font-size: 0.95rem; font-weight: 700;">Daftar Dokter Bertugas</h5>
                                                <?php if($doctorsInClinic->isEmpty()): ?>
                                                <div style="padding: 1.5rem; color: #64748b; font-size: 0.9rem; border: 1px dashed #e2e8f0; border-radius: 8px; text-align: center; background: #fff;">
                                                    Tidak ada dokter ditugaskan di klinik ini.
                                                </div>
                                                <?php else: ?>
                                                <table class="sub-table">
                                                    <thead>
                                                        <tr>
                                                            <th>Nama Dokter</th>
                                                            <th>Kontak</th>
                                                            <?php if(auth()->user()->role === 'SuperAdmin'): ?>
                                                            <th>Pindah Penugasan</th>
                                                            <?php endif; ?>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $doctorsInClinic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>
                                                                <div style="display: flex; align-items: center; gap: 0.5rem; font-weight: 600; color: #0f172a;">
                                                                    <i class="fas fa-user-md" style="color: #94a3b8;"></i>
                                                                    <?php echo e($doc->username); ?>

                                                                </div>
                                                            </td>
                                                            <td><?php echo e($doc->phoneNumber); ?></td>
                                                            <?php if(auth()->user()->role === 'SuperAdmin'): ?>
                                                            <td>
                                                                <form action="<?php echo e(route('reassignUserClinic', $doc->id)); ?>" method="POST" style="margin: 0;">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('PUT'); ?>
                                                                    <select name="idKlinik" class="formal-select" onchange="this.form.submit()">
                                                                        <option value="">-- Pindah Klinik --</option>
                                                                        <?php $__currentLoopData = $clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($c->id); ?>" <?php echo e($doc->idKlinik == $c->id ? 'selected' : ''); ?>>
                                                                            <?php echo e($c->namaKlinik); ?>

                                                                        </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </form>
                                                            </td>
                                                            <?php endif; ?>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
            </div>

            <?php if(auth()->user()->role === 'SuperAdmin'): ?>
            <aside class="account-sidebar">
                <div class="admin-add-card">
                    <div class="card-header">
                        <h3>Tambah Admin / Klinik Baru</h3>
                    </div>
                    <form class="admin-form" action="<?php echo e(route('registerKlinik')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Nama Klinik</label>
                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="text" placeholder="Masukkan nama klinik" name="username" />
                        </div>
                        <div class="form-group">
                            <label>Nomor HP</label>
                            <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="text" placeholder="Masukkan nomor HP" name="phoneNumber" />
                        </div>
                        <div class="form-group">
                            <label for="alamat">Alamat Lengkap</label>
                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <textarea id="alamat" name="alamat"
                                placeholder="Jln. Contoh No. 123, Kota, Provinsi, Kode Pos"><?php echo e(old('alamat')); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="password" placeholder="Password" name="password" />
                        </div>
                        <div class="form-group">
                            <label>Role</label>
                            <select name="role">
                                <option value="Admin">Admin</option>
                                <option value="SuperAdmin">Super Admin</option>
                            </select>
                        </div>
                        <button type="submit" class="export-btn" style="width:100%;">Buat Admin</button>
                    </form>
                </div>
            </aside>
            <?php endif; ?>
        </div>
    </section>
</div>


<script>
    function switchTab(event, tabId) {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
            btn.style.color = '#64748b';
            btn.style.borderBottom = 'none';
        });
        event.currentTarget.classList.add('active');
        event.currentTarget.style.color = '#6366f1';
        event.currentTarget.style.borderBottom = '2px solid #6366f1';

        document.querySelectorAll('.tab-pane').forEach(pane => {
            pane.style.display = 'none';
        });
        document.getElementById(tabId).style.display = 'block';
    }

    function toggleSubRow(id, rowElement) {
        const subRow = document.getElementById(id);
        if (subRow) {
            if (subRow.classList.contains('active')) {
                subRow.classList.remove('active');
                rowElement.classList.remove('expanded');
            } else {
                subRow.classList.add('active');
                rowElement.classList.add('expanded');
            }
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        // Quick live filter search box
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('keyup', function() {
                const query = this.value.toLowerCase();
                const rows = document.querySelectorAll('.searchable-row');

                rows.forEach(row => {
                    const name = row.querySelector('.searchable-name').textContent.toLowerCase();
                    const onclickAttr = row.getAttribute('onclick');
                    const match = onclickAttr ? onclickAttr.match(/'([^']+)'/) : null;
                    const subRowId = match ? match[1] : null;
                    const subRow = subRowId ? document.getElementById(subRowId) : null;

                    if (name.includes(query)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                        if (subRow) {
                            subRow.classList.remove('active');
                            row.classList.remove('expanded');
                        }
                    }
                });
            });
        }
    });
</script>


<style>
    .data-card {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05);
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    .formal-table {
        width: 100%;
        border-collapse: collapse;
        text-align: left;
    }

    .formal-table th {
        background-color: #f8fafc;
        color: #475569;
        font-weight: 600;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        padding: 1rem 1.5rem;
        border-bottom: 1px solid #e2e8f0;
    }

    .formal-table td {
        padding: 1rem 1.5rem;
        border-bottom: 1px solid #e2e8f0;
        color: #334155;
        font-size: 0.875rem;
        vertical-align: middle;
    }

    .formal-table tr:last-child td {
        border-bottom: none;
    }

    .formal-table tr:hover {
        background-color: #f8fafc;
    }

    .user-info-cell {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .user-icon {
        width: 40px;
        height: 40px;
        background: #eff6ff;
        color: #2563eb;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.1rem;
    }

    .user-details h4 {
        margin: 0;
        color: #0f172a;
        font-weight: 600;
        font-size: 0.95rem;
    }

    .user-details span {
        font-size: 0.8rem;
        color: #64748b;
    }

    .clinic-badge {
        display: inline-block;
        padding: 0.25rem 0.6rem;
        background: #eff6ff;
        color: #1e40af;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
        border: 1px solid #dbeafe;
    }

    .unassigned-badge {
        background: #fff1f2;
        color: #991b1b;
        border-color: #fecdd3;
    }

    .action-links {
        display: flex;
        gap: 0.75rem;
    }

    .action-link {
        color: #64748b;
        text-decoration: none;
        font-size: 0.85rem;
        font-weight: 600;
        transition: all 0.2s ease;
        background: none;
        border: none;
        padding: 0;
        cursor: pointer;
    }

    .action-link:hover {
        color: #3b82f6;
    }

    .action-link.delete:hover {
        color: #ef4444;
    }

    .main-row {
        cursor: pointer;
        transition: background-color 0.2s ease;
    }

    .main-row:hover {
        background-color: #f8fafc;
    }

    .main-row.expanded {
        background-color: #f8fafc;
        border-bottom: none;
    }

    .main-row.expanded td {
        border-bottom: none;
    }

    .sub-row {
        display: none;
        background-color: #f8fafc;
    }

    .sub-row.active {
        display: table-row;
    }

    .sub-table-container {
        padding: 1.5rem 1.5rem 1.5rem 4rem;
    }

    .expand-indicator {
        color: #94a3b8;
        font-size: 0.8rem;
        transition: transform 0.2s ease;
    }

    .main-row.expanded .expand-indicator {
        transform: rotate(90deg);
    }

    .formal-select {
        padding: 0.4rem 0.65rem;
        border: 1px solid #cbd5e1;
        border-radius: 8px;
        font-size: 0.8rem;
        color: #334155;
        background-color: #fff;
        outline: none;
        transition: all 0.2s ease;
    }

    .formal-select:focus {
        border-color: #6366f1;
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.15);
    }

    .sub-table {
        width: 100%;
        border-collapse: collapse;
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        overflow: hidden;
    }

    .sub-table th {
        background-color: #f8fafc;
        padding: 0.75rem 1rem;
        font-size: 0.75rem;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        border-bottom: 1px solid #e2e8f0;
    }

    .sub-table td {
        padding: 0.75rem 1rem;
        font-size: 0.85rem;
        border-bottom: 1px solid #f1f5f9;
        color: #334155;
    }

    .sub-table tr:last-child td {
        border-bottom: none;
    }

    .role-badge {
        padding: 0.3rem 0.75rem;
        border-radius: 99px;
        font-size: 0.8rem;
        font-weight: 600;
        display: inline-block;
    }

    .role-superadmin {
        background: rgba(99, 102, 241, 0.1);
        color: #6366f1;
    }

    .role-admin {
        background: rgba(59, 130, 246, 0.1);
        color: #3b82f6;
    }

    .role-user {
        background: rgba(107, 114, 128, 0.1);
        color: #6b7280;
    }

    .role-unassigned {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\1.CODING\1.Shigoto\1.Obat\obat\resources\views/admin/list/listAkun.blade.php ENDPATH**/ ?>