

<?php $__env->startSection('content'); ?>
<div class="main-content">
    <header class="header">
        <div class="header-left">
            <button class="menu-toggle">
                <i class="fas fa-bars"></i>
            </button>
            <h1 id="page-title">Dashboard</h1>
        </div>
    </header>

    <section id="dashboard" class="content-section active">
        <div class="section-header">
            <h2>Dashboard</h2>
        </div>

        <div class="stats-grid">
            <div class="stat-card" data-detail="revenue">
                <div class="stat-icon">
                    <i class="fas fa-wallet"></i>
                </div>
                <div class="stat-info">
                    <h3>Rp <?php echo e(number_format($totalPendapatan, 0, ',', '.')); ?></h3>
                    <p>Total Pendapatan</p>
                </div>
            </div>
            <div class="stat-card" data-detail="transactions">
                <div class="stat-icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo e($totalTransaksiHariIni); ?></h3>
                    <p>Transaksi Hari Ini</p>
                </div>
            </div>
            <div class="stat-card" data-detail="products">
                <div class="stat-icon">
                    <i class="fas fa-box-open"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo e($totalProdukTerjual); ?></h3>
                    <p>Produk Terjual</p>
                </div>
            </div>
        </div>

        <div class="detail-panel-container">
            <div class="detail-panel detail-revenue active" id="detail-revenue">
                <div class="detail-panel-header">
                    <div>
                        <h3>Detail Total Pendapatan</h3>
                        <p>Grafik pendapatan per hari, bulan, dan tahun.</p>
                    </div>
                    <div class="detail-tabs">
                        <button class="detail-tab active" data-period="daily">Harian</button>
                        <button class="detail-tab" data-period="monthly">Bulanan</button>
                        <button class="detail-tab" data-period="yearly">Tahunan</button>
                    </div>
                </div>
                <div class="detail-chart-card">
                    <canvas id="revenuePeriodChart"></canvas>
                </div>
                <div class="detail-summary-grid">
                    <div class="detail-summary-card">
                        <span>Total Minggu Ini</span>
                        <strong>Rp <?php echo e(number_format($pendapatanMingguan, 0, ',', '.')); ?></strong>
                    </div>
                    <div class="detail-summary-card">
                        <span>Total Bulan Ini</span>
                        <strong>Rp <?php echo e(number_format($pendapatanBulanIni, 0, ',', '.')); ?></strong>
                    </div>
                    <div class="detail-summary-card">
                        <span>Pertumbuhan</span>
                        <strong class="<?php echo e($pertumbuhan >= 0 ? 'text-success' : 'text-danger'); ?>"><?php echo e($pertumbuhan > 0 ? '+' : ''); ?><?php echo e($pertumbuhan); ?>%</strong>
                    </div>
                </div>
            </div>

            <div class="detail-panel detail-transactions" id="detail-transactions">
                <div class="detail-panel-header">
                    <div>
                        <h3>Detail Transaksi Hari Ini</h3>
                        <p>Item yang dibeli dan informasi pembeli.</p>
                    </div>
                </div>
                <div class="detail-list-grid">
                    <div class="detail-list-card">
                        <h4>Top Item</h4>
                        <ul>
                            <?php $__empty_1 = true; $__currentLoopData = $topItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li><?php echo e($item->produk->namaProduk ?? 'Produk Dihapus'); ?> <span><?php echo e($item->total_qty); ?>x</span></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li>Belum ada data</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="detail-list-card">
                        <h4>Pembeli Teratas Hari Ini</h4>
                        <ul>
                            <?php $__empty_1 = true; $__currentLoopData = $topBuyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li><?php echo e($buyer->user->username ?? 'User Dihapus'); ?> <span><?php echo e($buyer->total_transaksi); ?> transaksi</span></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li>Belum ada data</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="detail-panel detail-products" id="detail-products">
                <div class="detail-panel-header">
                    <div>
                        <h3>Detail Produk Terjual</h3>
                        <p>Produk unggulan dan performa penjualan.</p>
                    </div>
                </div>
                <div class="detail-list-grid">
                    <div class="detail-list-card wide">
                        <h4>Produk Unggulan</h4>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Produk</th>
                                    <th>Terjual</th>
                                    <th>Stok</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $produkUnggulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($item->produk->namaProduk ?? 'Produk Dihapus'); ?></td>
                                    <td><?php echo e($item->total_terjual); ?></td>
                                    <td><?php echo e($item->produk->stok ?? 0); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3">Belum ada data</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="detail-panel detail-average" id="detail-average">
                <div class="detail-panel-header">
                    <div>
                        <h3>Detail Rata-rata Transaksi</h3>
                        <p>Analisis nilai transaksi dan kontribusi kategori.</p>
                    </div>
                </div>
                <div class="detail-summary-grid">
                    <div class="detail-summary-card">
                        <span>Nilai Transaksi Rata-rata</span>
                        <strong>Rp <?php echo e(number_format($rataRataTransaksi, 0, ',', '.')); ?></strong>
                    </div>
                    <?php $__currentLoopData = $kategoriKontribusi->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="detail-summary-card">
                        <span>Kontribusi <?php echo e($kat->namaCategory); ?></span>
                        <strong><?php echo e($totalPenjualanSemuaKategori > 0 ? round(($kat->total_penjualan / $totalPenjualanSemuaKategori) * 100) : 0); ?>%</strong>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="detail-chart-card small">
                    <canvas id="averageTrendChart"></canvas>
                </div>
            </div>
        </div>
    </section>

    <section id="penjualan" class="content-section">
        <div class="section-header">
            <h2>Laporan Penjualan</h2>
            <div>
                <input type="date" class="date-filter" />
                <input type="date" class="date-filter" />
                <button class="filter-btn">Filter</button>
                <button class="export-btn">Export</button>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-coins"></i>
                </div>
                <div class="stat-info">
                    <h3>Rp <?php echo e(number_format($pendapatanMingguan, 0, ',', '.')); ?></h3>
                    <p>Pendapatan Mingguan</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-cart-plus"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo e(number_format($totalPesanan, 0, ',', '.')); ?></h3>
                    <p>Total Pesanan</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="stat-info">
                    <h3 class="<?php echo e($pertumbuhan >= 0 ? 'text-success' : 'text-danger'); ?>"><?php echo e($pertumbuhan > 0 ? '+' : ''); ?><?php echo e($pertumbuhan); ?>%</h3>
                    <p>Pertumbuhan</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-user-check"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo e(number_format($pelangganAktif, 0, ',', '.')); ?></h3>
                    <p>Pelanggan Aktif</p>
                </div>
            </div>
        </div>

        <div class="charts-grid">
            <div class="chart-card">
                <div class="chart-header">
                    <h3>Penjualan Harian</h3>
                    <button class="print-btn">Print</button>
                </div>
                <canvas id="dailyChart"></canvas>
            </div>
            <div class="chart-card">
                <div class="chart-header">
                    <h3>Penjualan Bulanan</h3>
                </div>
                <canvas id="monthlyChart"></canvas>
            </div>
        </div>
    </section>
</div>
<script>
    window.chartData = {
        dailyLabels: <?php echo json_encode($dailyLabels); ?>,
        dailyData: <?php echo json_encode($dailyData); ?>,
        monthlyLabels: <?php echo json_encode($monthlyLabels); ?>,
        monthlyData: <?php echo json_encode($monthlyData); ?>,
        yearlyLabels: <?php echo json_encode($yearlyLabels); ?>,
        yearlyData: <?php echo json_encode($yearlyData); ?>,
        kategoriLabels: <?php echo json_encode($kategoriKontribusi->pluck('namaCategory')); ?>,
        kategoriData: <?php echo json_encode($kategoriKontribusi->pluck('total_penjualan')); ?>

    };
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\1.CODING\1.Shigoto\1.Obat\obat\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>