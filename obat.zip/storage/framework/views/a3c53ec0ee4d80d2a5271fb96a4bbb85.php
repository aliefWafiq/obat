<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - ObatKita</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/obatkitalogo.png')); ?>">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style/register.css')); ?>">
</head>

<body>
    <div class="auth-wrapper">
        <div class="auth-container">
            <div class="auth-left">
                <h2>Bergabunglah dengan Kami!</h2>
                <p>Daftarkan akun baru dan nikmati pengalaman berbelanja yang lebih baik dengan berbagai keuntungan eksklusif.</p>
                <div class="auth-left-features">
                    <div class="feature-item"><i class="fas fa-star"></i>
                        <div class="feature-item-text"><strong>Member Eksklusif</strong>Dapatkan diskon dan penawaran khusus untuk member baru</div>
                    </div>
                    <div class="feature-item"><i class="fas fa-gift"></i>
                        <div class="feature-item-text"><strong>Bonus Poin Reward</strong>Kumpulkan poin dari setiap pembelian</div>
                    </div>
                    <div class="feature-item"><i class="fas fa-lock"></i>
                        <div class="feature-item-text"><strong>Data Aman Terjamin</strong>Privasi dan keamanan data Anda adalah prioritas kami</div>
                    </div>
                </div>
            </div>
            <div class="auth-right">
                <div class="auth-brand"><a href="/"><img src="<?php echo e(asset('img/obatkitalogo.png')); ?>" alt="ObatKita Logo" class="auth-logo-img"></a></div>
                <h3>Buat Akun Baru</h3>
                <p class="auth-right-subtitle">Isi data diri Anda dengan lengkap dan benar</p>
                <?php if(session('error')): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i><span><?php echo e(session('error')); ?></span></div>
                <?php endif; ?>
                <?php if(session('otp_sent')): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i><span><?php echo e(session('success')); ?></span></div>
    <form action="<?php echo e(route('verifyOTP')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="userId" value="<?php echo e(session('userId')); ?>">
        <div class="form-group">
            <label for="otp">Kode OTP</label>
            <input type="text" id="otp" name="otp" placeholder="Masukkan kode OTP" required>
            <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit" class="auth-btn" id="submitBtn"><i class="fas fa-check"></i> Verifikasi OTP</button>
    </form>
<?php else: ?>
    <form action="/register/action" method="POST" onsubmit="handleSubmit(this)">
        <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="username">Nama Lengkap</label>
                        <input type="text" id="username" name="username" placeholder="Masukkan nama Anda" value="<?php echo e(old('username')); ?>" required>
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="phoneNumber">Nomor HP</label>
                        <input type="number" id="phoneNumber" name="phoneNumber" placeholder="08xxxxxxxxxx" value="<?php echo e(old('phoneNumber')); ?>" required>
                        <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="alamat">Alamat Lengkap</label>
                        <textarea id="alamat" name="alamat" placeholder="Jln. Contoh No. 123, Kota, Provinsi, Kode Pos" required><?php echo e(old('alamat')); ?></textarea>
                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" placeholder="Masukkan password Anda" required>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="auth-btn" id="submitBtn"><i class="fas fa-user-plus"></i> Buat Akun</button>
                </form>
                <?php endif; ?>
                
                <div class="auth-footer">Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Masuk sekarang</a></div>
            </div>
        </div>
    </div>
    <footer>
        <div>
            <a href="#">Tentang Kami</a>
            <a href="#">Syarat &amp; Ketentuan</a>
            <a href="#">Kebijakan Privasi</a>
            <a href="#">Hubungi Kami</a>
        </div>
        <p style="margin-top:15px;">&copy; 2026 ObatKita. Semua hak dilindungi.</p>
    </footer>
    <script src="<?php echo e(asset('js/register.js')); ?>"></script>
</body>

</html><?php /**PATH E:\1.CODING\1.Shigoto\1.Obat\obat\resources\views/register.blade.php ENDPATH**/ ?>