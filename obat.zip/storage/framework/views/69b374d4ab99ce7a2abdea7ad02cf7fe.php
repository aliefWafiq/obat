<?php $__env->startPush('styles'); ?>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('style/product.css')); ?>" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('nav'); ?>
<div class="search-box">
    <svg class="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="11" cy="11" r="8" />
        <path d="m21 21-4.35-4.35" />
    </svg>
    <input type="text" id="search-input" placeholder="Cari produk..." class="search-input" />
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- PROGRAM SLIDER -->
<?php if(isset($BuatProgram) && $BuatProgram->count() > 0): ?>
<section class="program-slider-section">
    <div class="slider-container">
        <div class="slider-wrapper">
            <?php $__currentLoopData = $BuatProgram; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="program-slide <?php echo e($index === 0 ? 'active' : ''); ?>">
                <div class="slide-content">
                    <span class="program-badge"><i class="fas fa-ticket"></i> <?php echo e($program->tagProgram); ?></span>
                    <h2 class="program-title"><?php echo e($program->judul); ?></h2>
                    <p class="program-desc"><?php echo e($program->deskripsi); ?></p>
                    <a href="#catalog-title" class="btn-program">Belanja Sekarang</a>
                </div>
                <div class="slide-image" style="background-image: url('<?php echo e(asset('storage/' . $program->gambar)); ?>')"></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <?php if($BuatProgram->count() > 1): ?>
        <!-- Controls -->
        <button class="slider-nav prev-btn" aria-label="Previous Slide"><i class="fas fa-chevron-left"></i></button>
        <button class="slider-nav next-btn" aria-label="Next Slide"><i class="fas fa-chevron-right"></i></button>
        
        <!-- Dots -->
        <div class="slider-dots">
            <?php $__currentLoopData = $BuatProgram; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="dot <?php echo e($index === 0 ? 'active' : ''); ?>" data-index="<?php echo e($index); ?>"></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>

<!-- CATALOG -->
<section class="catalog">
    <div class="catalog-header">
        <div>
            <span class="eyebrow">Obat Kita</span>
            <h2 class="catalog-h2" id="catalog-title">Semua <em>Produk</em></h2>
        </div>
    </div>

    <!-- FILTER TABS -->
    <div class="filter-tabs" id="filter-tabs">
        <button class="tab active" data-cat="semua">Semua</button>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button class="tab" data-cat="<?php echo e($e->id); ?>"><?php echo e($e->namaCategory); ?></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- SORT ROW -->
    <div class="sort-row">
        <span id="result-count"></span>
        <select class="sort-select" id="sort-select">
            <option value="default">Terpopuler</option>
            <option value="price-asc">Harga: Rendah ke Tinggi</option>
            <option value="price-desc">Harga: Tinggi ke Rendah</option>
            <option value="newest">Terbaru</option>
        </select>
    </div>

    <!-- PRODUCT GRID -->
    <div class="product-grid" id="product-grid">
        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product-card" data-id="<?php echo e($e->idCategory); ?>">
            <div class="card-img-wrap">
                <div class="card-img-placeholder">
                    <img src="<?php echo e(asset('storage/' . $e->gambar)); ?>" alt="<?php echo e($e->namaProduk); ?>" class="card-img">
                </div>
                <?php if($e->stok == 0): ?>
                <div class="card-overlay">Habis</div>
                <?php else: ?>
                <button type="button" class="card-overlay open-drawer-btn" style="cursor: pointer;"
                    data-id="<?php echo e($e->id); ?>"
                    data-name="<?php echo e($e->namaProduk); ?>"
                    data-desc="<?php echo e($e->deskripsi); ?>"
                    data-harga="Rp <?php echo e(number_format($e->harga, 0, ',', '.')); ?>"
                    data-raw-harga="<?php echo e($e->harga); ?>"
                    data-stok="<?php echo e($e->stok); ?>"
                    data-gambar="<?php echo e(asset('storage/' . $e->gambar)); ?>">
                    Tambah ke Keranjang
                </button>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <span class="card-category-label"><?php echo e($e->category->namaCategory ?? 'Obat & Kesehatan'); ?></span>
                <div class="card-name" title="<?php echo e($e->namaProduk); ?>"><?php echo e($e->namaProduk); ?></div>
                <div class="card-desc"><?php echo e($e->deskripsi); ?></div>
                <div class="card-footer">
                    <div>
                        <span class="card-price">Rp <?php echo e(number_format($e->harga, 0, ',', '.')); ?></span>
                    </div>
                    <?php if($e->stok > 0): ?>
                    <span class="card-stock-info">Stok: <b><?php echo e($e->stok); ?></b></span>
                    <?php else: ?>
                    <span class="stok-habis-label">Habis</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- PAGINATION -->
    <div class="pagination">
        <button class="page-btn active">1</button>
        <button class="page-btn">2</button>
        <button class="page-btn">3</button>
        <button class="page-btn">›</button>
    </div>

    <!-- Shopee-style Slide-up Add to Cart Drawer -->
    <div id="cart-drawer-overlay" class="cart-drawer-overlay">
        <div id="cart-drawer" class="cart-drawer">
            <!-- Close Button -->
            <button type="button" class="drawer-close-btn">&times;</button>
            
            <form id="drawer-form" action="<?php echo e(route('masukKeranjang')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="produk_id" id="drawer-product-id">
                
                <!-- Product Information -->
                <div class="drawer-product-info">
                    <div class="drawer-img-wrap">
                        <img id="drawer-product-img" src="" alt="">
                    </div>
                    <div class="drawer-details">
                        <h3 id="drawer-product-name">Nama Produk</h3>
                        <p id="drawer-product-desc">Deskripsi singkat produk</p>
                        <div class="drawer-price-stock">
                            <span id="drawer-product-price" class="drawer-price">Rp 0</span>
                            <span id="drawer-product-stock" class="drawer-stock">Stok: 0</span>
                        </div>
                    </div>
                </div>
                
                <!-- Quantity Selector Row -->
                <div class="drawer-qty-row">
                    <span class="qty-label">Jumlah</span>
                    <div class="qty-box">
                        <button type="button" class="qty-btn minus">-</button>
                        <input type="number" name="jumlah" class="qty-input" id="drawer-qty-input" min="1" value="1" readonly>
                        <button type="button" class="qty-btn plus">+</button>
                    </div>
                </div>
                
                <!-- Action Buttons -->
                <div class="drawer-actions">
                    <button type="submit" class="drawer-btn submit-btn">Masukkan Keranjang</button>
                </div>
            </form>
        </div>
    </div>
</section>

<!-- FOOTER -->
<footer class="main-footer">
    <div class="footer-container">
        <!-- Column 1: Brand Profile -->
        <div class="footer-column brand-profile">
            <h3 class="footer-logo"><strong><em>obat</em>kita.</strong></h3>
            <p class="brand-desc">ObatKita menyediakan obat-obatan resmi, vitamin, suplemen makanan, serta alat kesehatan berkualitas tinggi 100% asli untuk menunjang kesehatan Anda sekeluarga.</p>
        </div>

        <!-- Column 2: Navigation Links -->
        <div class="footer-column">
            <h4 class="footer-title">Tautan Cepat</h4>
            <ul class="footer-links">
                <li><a href="<?php echo e(route('home')); ?>">Beranda Belanja</a></li>
                <li><a href="#catalog-title">Katalog Produk</a></li>
                <li><a href="<?php echo e(route('keranjang')); ?>">Keranjang Belanja</a></li>
                <li><a href="<?php echo e(route('pemesanan')); ?>">Riwayat Transaksi</a></li>
            </ul>
        </div>

        <!-- Column 3: Category Highlights -->
        <div class="footer-column">
            <h4 class="footer-title">Kategori Terpopuler</h4>
            <ul class="footer-links">
                <?php if(isset($categories)): ?>
                    <?php $__currentLoopData = $categories->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="#catalog-title" class="footer-cat-link" data-cat="<?php echo e($cat->id); ?>"><?php echo e($cat->namaCategory); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <li><a href="#catalog-title">Obat Resep</a></li>
                    <li><a href="#catalog-title">Vitamin & Suplemen</a></li>
                    <li><a href="#catalog-title">Ibu & Anak</a></li>
                    <li><a href="#catalog-title">Alat Kesehatan</a></li>
                <?php endif; ?>
            </ul>
        </div>

        <!-- Column 4: Contact Info -->
        <div class="footer-column contact-info">
            <h4 class="footer-title">Hubungi Kami</h4>
            <ul class="contact-list">
                <li>
                    <i class="fas fa-map-marker-alt"></i>
                    <span>Jl. Sentosa, Perumahan Grya Masmur 2, Blok Tulip No. 24, Pekanbaru, Riau.</span>
                </li>
                <li>
                    <i class="fas fa-phone-alt"></i>
                    <span>+62 878-7777-0155</span>
                </li>
            </ul>
        </div>
    </div>

    <!-- Footer Bottom -->
    <div class="footer-bottom">
        <div class="footer-bottom-container">
            <div class="copyright">
                <p>&copy; 2026 <strong>ObatKita</strong>. Seluruh Hak Cipta Dilindungi.</p>
            </div>
            <div class="payment-partners">
                <span>Pembayaran & Pengiriman Aman:</span>
                <div class="partner-logos">
                    <i class="fab fa-cc-visa" title="Visa"></i>
                    <i class="fab fa-cc-mastercard" title="Mastercard"></i>
                    <i class="fas fa-university" title="Transfer Bank"></i>
                    <i class="fas fa-truck" title="Kurir Instan"></i>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/product.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.mainLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\1.CODING\1.Shigoto\1.Obat\obat\resources\views/user/home.blade.php ENDPATH**/ ?>