<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create("kuantitasDiskon", function (Blueprint $table) {
            $table->id();
            $table->foreignId('idProduk')->references('id')->on('produk')->onDelete('cascade');
            $table->integer('minimalBeli');
            $table->integer('diskon');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('kuantitasDiskon');
    }
};
