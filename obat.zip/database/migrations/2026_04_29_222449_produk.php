<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        schema::create('produk', function(Blueprint $table){
            $table->id();
            $table->string('kodeProduk')->unique();
            $table->string('gambar');
            $table->string('namaProduk');
            $table->text('deskripsi');
            $table->foreignId('idCategory')->constrained('category')->onDelete('cascade');
            $table->bigInteger('harga');
            $table->integer('stok');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
