<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('username');
            $table->string('phoneNumber')->unique();
            $table->string('password');
            $table->unsignedBigInteger('idKlinik')->nullable();
            $table->enum('role', ['User', 'Admin', 'SuperAdmin'])->default('User');
            $table->text('alamat');
            $table->timestamps();
        });

        Schema::table('users', function (Blueprint $table) {
            $table->foreign('idKlinik')->references('id')->on('kodeKlinik')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
